#include <vector>
#include <stdio.h>
#include <string.h>
#include <string>
#include <queue>
using namespace std;
struct huffman_node{
    int w;
    char v;
    huffman_node *L,*R;
    huffman_node(int _w=0,char _v=0){
        w=_w,v=_v;
        L=R=NULL;
    }
};
struct huffman_node_cmp{
    bool operator ()(huffman_node* const& a,huffman_node* const& b){
        return a->w>b->w;
    }
};
struct bitcode{
    vector<unsigned>vc;
    int top;
    bitcode(){
        top=0;
    }
    void set_1(int idx){
        int x=idx/32,y=idx%32;
        if(x==(int)vc.size())vc.push_back(0);
        vc[x]|=(1<<y);
    }
    void set_0(int idx){
        int x=idx/32,y=idx%32;
        if(x==(int)vc.size())vc.push_back(0);
        vc[x]&=~(1<<y);
    }
    void push_back(int v){
        if(v==0){
            set_0(top++);
        }else if(v==1){
            set_1(top++);
        } 
    }
    void pop_back(){
        top--;
    }
    int size(){
        return top;
    }
    int at(int idx){
        int x=idx/32,y=idx%32;
        return (vc[x]>>y)&1;
    }
    void print(){
        for(int i=0;i<top;i++){
            printf("%d",at(i));
        }
        puts("");
    }
    void clear(){
        top=0;
        vc.clear();
    }
    void append(const bitcode &n){
        bitcode b=n;
        for(int i=0;i<b.top;i++){
            push_back(b.at(i));
        }
    }
};
struct huffman{
    huffman_node *root;
    vector<char>use;
    int cnt[128];
    bitcode code[128];
    bitcode encoded;
    string decoded;
    huffman(){
        root=NULL;
        memset(cnt,0,sizeof(cnt));
        for(int i=0;i<128;i++){
            code[i].clear();
        }
    }
    void count(const char *s){
        memset(cnt,0,sizeof(cnt));
        use.clear();
        for(int i=0;s[i];i++){
            if(cnt[(int)s[i]]==0){
                use.push_back(s[i]);
            }
            cnt[(int)s[i]]++;
        }
    }
    void init(const char *s){
        count(s);
        priority_queue<huffman_node*,vector<huffman_node*>,huffman_node_cmp> pq;
        for(int i=0;i<128;i++){
            if(cnt[i]){
                pq.push(new huffman_node(cnt[i],(char)i));
            }
        }
        while(pq.size()>1){
            huffman_node *a=pq.top();pq.pop();
            huffman_node *b=pq.top();pq.pop();
            huffman_node *c=new huffman_node(a->w+b->w);
            c->L=a,c->R=b;
            pq.push(c);
        }
        root=pq.top();pq.pop();
        decoded=s;
        gencode();
        encode();
    }
    void gencode(){
        bitcode tc=bitcode();
        _gencode(root,0,tc);
    }
    void _gencode(huffman_node *tr,int idx, bitcode &tc){
        if(!tr->L&&!tr->R){
            code[(int)tr->v]=tc;
            return;
        }
        if(tr->L){
            tc.push_back(0);
            _gencode(tr->L,idx+1,tc);
            tc.pop_back();
        }
        if(tr->R){
            tc.push_back(1);
            _gencode(tr->R,idx+1,tc);
            tc.pop_back();
        }
    }
    void encode(){
        const char *s=decoded.c_str();
        encoded.clear();
        for(int i=0;s[i];i++){
            encoded.append(code[(int)s[i]]);
        }
    }
    void decode(){
        decoded="";
        for(int i=0;i<encoded.size();){
            for(int j=0;j<(int)use.size();j++){
                if(i+code[(int)use[j]].size()>encoded.size())
                    continue;
                bool tf=true;
                for(int k=0;k<code[(int)use[j]].size()&&tf;k++){
                    tf=encoded.at(i+k)==code[(int)use[j]].at(k);
                }
                if(tf){
                    decoded+=use[j];
                    i+=code[(int)use[j]].size();
                }
            }
        }
    }
    void print(){
        _print(root);
    }
    void _print(huffman_node *tr){
        if(!tr)return;
        _print(tr->L);
        printf("%c\n",tr->v); 
        _print(tr->R);
    }
    void print_code(){
        for(int i=0;i<(int)use.size();i++){
            printf("%c: ",use[i]);
            code[(int)use[i]].print();
        }
    }
    void print_encoded(){
        encoded.print();
        puts("");
    }
    void print_decoded(){
        puts(decoded.c_str());
    }

};
char s[3000];
int main(){
    while(gets(s)!=NULL){
        huffman h;
        h.init(s);
        //puts(s);
        //h.print();
        //h.print_code();
        //h.print_encoded();
        h.decode();
        h.print_decoded();
    }
    return 0;
}
